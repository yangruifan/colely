#!/usr/bin/env python
# encoding:utf-8
# @Time   : 2018/12/11
# @File   : test.py

from config import *

if __name__ == '__main__':
    print(imgRedisConf)